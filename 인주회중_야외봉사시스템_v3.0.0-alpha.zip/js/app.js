const K='inju_v3_alpha_';
let DATA=null, current='all', onlyLeft=false;

async function init(){
  try{
    const res=await fetch('data/geolmaeri.json');
    DATA=await res.json();
  }catch(e){
    alert('데이터 파일을 읽지 못했습니다. GitHub에 data/geolmaeri.json이 올라갔는지 확인하세요.');
    return;
  }
  buildAreaButtons();
  buildPairArea();
  renderAll();
  if('serviceWorker' in navigator){navigator.serviceWorker.register('sw.js').catch(()=>{});}
}
function save(k,v){localStorage.setItem(K+k,JSON.stringify(v))}
function load(k,d){try{let v=JSON.parse(localStorage.getItem(K+k));return v??d}catch(e){return d}}
function go(id){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  renderAll();
}
function todayKey(){return new Date().toLocaleDateString('ko-KR')}
function areas(){return DATA.areas}
function areaObj(id){return areas().find(a=>a.id===id)}
function houses(id=current){return DATA.houses[id]||[]}

function buildAreaButtons(){
  const box=document.getElementById('areaButtons');
  box.innerHTML='';
  areas().forEach(a=>{
    const b=document.createElement('button');
    b.textContent=(a.id==='all'?'📍 ':'')+a.name;
    b.onclick=()=>openArea(a.id);
    box.appendChild(b);
  });
}
function buildPairArea(){
  const s=document.getElementById('pairArea');
  s.innerHTML='<option value="">담당 구역 선택</option>';
  areas().filter(a=>a.id!=='all').forEach(a=>{
    s.innerHTML += `<option>${a.name}</option>`;
  });
}
function statusKey(areaId,i){return 'status_'+areaId+'_'+i}
function memoKey(areaId,i){return 'memo_'+areaId+'_'+i}

function renderBrief(){
  const people=load('people',[]);
  const total=houses('all').length;
  let done=0;
  houses('all').forEach((h,i)=>{if(load(statusKey('all',i),'')==='done')done++});
  document.getElementById('brief').innerHTML=
    `📅 ${todayKey()}<br>👥 오늘 참여: <b>${people.length}명</b><br>🗺️ 담당 구역: <b>걸매리</b><br>🏠 전체 방문 대상: <b>${total}</b><br>✅ 완료: <b>${done}</b><br>⏳ 남은 가구: <b>${total-done}</b>`;
}
function openArea(id){current=id;onlyLeft=false;go('area');renderArea()}
function renderArea(){
  if(!DATA)return;
  const a=areaObj(current), arr=houses(current);
  document.getElementById('areaTitle').textContent=a.name;
  document.getElementById('mapBox').innerHTML=`<iframe src="${a.map}" loading="lazy"></iframe>`;
  let done=0;
  arr.forEach((h,i)=>{if(load(statusKey(current,i),'')==='done')done++});
  const rate=arr.length?Math.round(done/arr.length*100):0;
  document.getElementById('countBadge').textContent=`완료 ${done}/${arr.length}`;
  document.getElementById('rateBadge').textContent=`진행률 ${rate}%`;
  document.getElementById('progressBar').style.width=rate+'%';

  const box=document.getElementById('houses'); box.innerHTML='';
  arr.forEach((h,i)=>{
    const st=load(statusKey(current,i),'');
    if(onlyLeft && st==='done') return;
    const memo=load(memoKey(current,i),h.memo||'');
    const div=document.createElement('div');
    div.className='house '+st;
    div.innerHTML=`<div class="addr">${h.no}. ${h.address}</div>
      <div class="memo">${memo||''}</div>
      <textarea placeholder="메모 입력" oninput="setMemo(${i},this.value)">${memo||''}</textarea>
      <div class="status">
        <button class="small green" onclick="setStatus(${i},'done')">방문함</button>
        <button class="small yellow" onclick="setStatus(${i},'absent')">부재중</button>
        <button class="small red" onclick="setStatus(${i},'reject')">방문거절</button>
        <button class="small gray" onclick="setStatus(${i},'closed')">폐문부재</button>
      </div>
      <button class="small sub" onclick="setStatus(${i},'')">상태해제</button>`;
    box.appendChild(div);
  });
}
function setStatus(i,st){save(statusKey(current,i),st);renderArea();renderBrief();renderLeader()}
function setMemo(i,v){save(memoKey(current,i),v)}
function toggleOnlyLeft(){onlyLeft=!onlyLeft;renderArea()}
function locateMe(){
  if(!navigator.geolocation){alert('GPS를 사용할 수 없습니다.');return}
  navigator.geolocation.getCurrentPosition(p=>{
    const lat=p.coords.latitude,lng=p.coords.longitude;
    document.getElementById('mapBox').innerHTML=`<iframe src="https://maps.google.com/maps?q=${lat},${lng}&z=17&output=embed"></iframe>`;
  },()=>alert('현재 위치 권한을 허용해 주세요.'));
}

function addPerson(){
  const input=document.getElementById('personName');
  const name=input.value.trim();
  if(!name)return;
  let people=load('people',[]);
  if(!people.includes(name))people.push(name);
  save('people',people); input.value=''; renderAll();
}
function clearToday(){if(confirm('오늘 참여 명단을 초기화할까요?')){save('people',[]);save('pairs',[]);renderAll()}}
function renderPeople(){
  const people=load('people',[]);
  document.getElementById('peopleList').innerHTML=people.length?people.map((p,i)=>`${i+1}. ${p}`).join('<br>'):'아직 참여자가 없습니다.';
}
function pairedNames(){return load('pairs',[]).flatMap(p=>[p.a,p.b])}
function renderLeader(){
  const people=load('people',[]), used=pairedNames(), remain=people.filter(p=>!used.includes(p));
  ['p1','p2'].forEach(id=>{
    const s=document.getElementById(id);
    s.innerHTML='<option value="">선택</option>'+remain.map(p=>`<option>${p}</option>`).join('');
  });
  const pairs=load('pairs',[]);
  document.getElementById('leaderDash').innerHTML=
    `오늘 참여: <b>${people.length}명</b><br>짝 편성: <b>${pairs.length}조</b><br>남은 사람: <b>${remain.length}명</b>`;
  document.getElementById('pairList').innerHTML=pairs.length?pairs.map((p,i)=>`<div class="pair"><b>${i+1}조</b><br>${p.a} + ${p.b}<br>담당: ${p.area||'미지정'}</div>`).join(''):'아직 편성된 짝이 없습니다.';
  document.getElementById('remainList').innerHTML=remain.length?remain.join('<br>'):'남은 사람이 없습니다.';
}
function makePair(){
  const a=document.getElementById('p1').value,b=document.getElementById('p2').value,area=document.getElementById('pairArea').value;
  if(!a||!b||a===b){alert('서로 다른 두 사람을 선택하세요.');return}
  let pairs=load('pairs',[]); pairs.push({a,b,area}); save('pairs',pairs); renderAll();
}
function clearPairs(){if(confirm('짝 편성을 초기화할까요?')){save('pairs',[]);renderAll()}}

function standApply(){
  const name=prompt('전시대 신청자 이름');
  if(!name)return;
  let list=load('stand',[]); list.push({name,day:todayKey()}); save('stand',list);renderStand();
}
function clearStand(){if(confirm('전시대 기록을 초기화할까요?')){save('stand',[]);renderStand()}}
function renderStand(){
  const list=load('stand',[]);
  document.getElementById('standList').innerHTML=list.length?list.map((x,i)=>`${i+1}. ${x.day} - ${x.name}`).join('<br>'):'전시대 신청 기록이 없습니다.';
}
function renderAll(){if(!DATA)return;renderBrief();renderPeople();renderLeader();renderStand();if(document.getElementById('area').classList.contains('active'))renderArea()}
init();
