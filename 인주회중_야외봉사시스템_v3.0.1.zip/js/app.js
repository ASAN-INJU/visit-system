const K='inju_v3_0_1_';
let DATA=null,current='all',onlyLeft=false;

async function init(){
  try{
    const res=await fetch('data/geolmaeri.json?ver=301');
    DATA=await res.json();
  }catch(e){
    alert('data/geolmaeri.json 파일을 읽지 못했습니다.');
    return;
  }
  buildAreaButtons();
  buildPairArea();
  renderAll();
  if('serviceWorker' in navigator){navigator.serviceWorker.register('sw.js').catch(()=>{});}
}
function save(k,v){localStorage.setItem(K+k,JSON.stringify(v))}
function load(k,d){try{let v=JSON.parse(localStorage.getItem(K+k));return v??d}catch(e){return d}}
function go(id){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
  renderAll();
}
function todayKey(){return new Date().toLocaleDateString('ko-KR')}
function areas(){return DATA.areas}
function areaObj(id){return areas().find(a=>a.id===id)}
function houses(id=current){return DATA.houses[id]||[]}
function statusKey(areaId,i){return 'status_'+areaId+'_'+i}
function memoKey(areaId,i){return 'memo_'+areaId+'_'+i}

function buildAreaButtons(){
  const box=document.getElementById('areaButtons');
  box.innerHTML='';
  areas().forEach(a=>{
    const b=document.createElement('button');
    b.textContent=(a.id==='all'?'📍 ':'')+a.name;
    b.onclick=()=>openArea(a.id);
    box.appendChild(b);
  });
}
function buildPairArea(){
  const s=document.getElementById('pairArea');
  s.innerHTML='<option value="">담당 구역 선택</option>';
  areas().filter(a=>a.id!=='all').forEach(a=>s.innerHTML+=`<option>${a.name}</option>`);
}
function calcArea(id){
  let total=houses(id).length, done=0, absent=0, reject=0, closed=0;
  houses(id).forEach((h,i)=>{
    let st=load(statusKey(id,i),'');
    if(st==='done')done++;
    if(st==='absent')absent++;
    if(st==='reject')reject++;
    if(st==='closed')closed++;
  });
  return {total,done,absent,reject,closed,left:total-done,rate:total?Math.round(done/total*100):0};
}
function renderBrief(){
  const people=load('people',[]);
  const c=calcArea('all');
  document.getElementById('brief').innerHTML=
    `📅 ${todayKey()}<br>👥 오늘 참여: <b>${people.length}명</b><br>🗺️ 담당 구역: <b>걸매리</b><br>🏠 전체 방문 대상: <b>${c.total}</b><br>✅ 완료: <b>${c.done}</b><br>⏳ 남은 가구: <b>${c.left}</b><br>📊 전체 진행률: <b>${c.rate}%</b>`;
}
function openArea(id){current=id;onlyLeft=false;save('lastArea',id);go('area');renderArea()}
function renderArea(){
  if(!DATA)return;
  const a=areaObj(current), arr=houses(current), c=calcArea(current);
  document.getElementById('areaTitle').textContent=a.name;
  document.getElementById('mapBox').innerHTML=`<iframe src="${a.map}" loading="lazy"></iframe>`;
  document.getElementById('countBadge').textContent=`완료 ${c.done}/${c.total}`;
  document.getElementById('rateBadge').textContent=`진행률 ${c.rate}%`;
  document.getElementById('progressBar').style.width=c.rate+'%';
  const box=document.getElementById('houses'); box.innerHTML='';
  arr.forEach((h,i)=>{
    const st=load(statusKey(current,i),'');
    if(onlyLeft && st==='done') return;
    const memo=load(memoKey(current,i),h.memo||'');
    const div=document.createElement('div');
    div.className='house '+st;
    div.innerHTML=`<div class="addr">${h.no}. ${h.address}</div>
      <div class="memo">${memo||''}</div>
      <textarea placeholder="메모 입력" oninput="setMemo(${i},this.value)">${memo||''}</textarea>
      <div class="status">
        <button class="small green" onclick="setStatus(${i},'done')">방문함</button>
        <button class="small yellow" onclick="setStatus(${i},'absent')">부재중</button>
        <button class="small red" onclick="setStatus(${i},'reject')">방문거절</button>
        <button class="small gray" onclick="setStatus(${i},'closed')">폐문부재</button>
      </div>
      <button class="small sub" onclick="setStatus(${i},'')">상태해제</button>`;
    box.appendChild(div);
  });
}
function setStatus(i,st){
  save(statusKey(current,i),st);
  save('lastArea',current);
  save('lastHouseIndex',i);
  renderArea(); renderBrief(); renderLeader();
}
function setMemo(i,v){save(memoKey(current,i),v)}
function toggleOnlyLeft(){onlyLeft=!onlyLeft;renderArea()}
function resumeVisit(){
  const area=load('lastArea','all');
  if(!DATA){go('home');return}
  openArea(area);
}
function locateMe(){
  if(!navigator.geolocation){alert('GPS를 사용할 수 없습니다.');return}
  navigator.geolocation.getCurrentPosition(p=>{
    const lat=p.coords.latitude,lng=p.coords.longitude;
    document.getElementById('mapBox').innerHTML=`<iframe src="https://maps.google.com/maps?q=${lat},${lng}&z=17&output=embed"></iframe>`;
  },()=>alert('현재 위치 권한을 허용해 주세요.'),{enableHighAccuracy:true,timeout:10000,maximumAge:0});
}

function searchHouses(q){
  q=(q||'').trim();
  const box=document.getElementById('searchResult');
  if(!q){box.innerHTML='';return}
  const results=[];
  ['gm1','gm2','gm3','gm4'].forEach(areaId=>{
    houses(areaId).forEach((h,i)=>{
      const text=(h.no+' '+h.address+' '+(h.memo||'')).toLowerCase();
      if(text.includes(q.toLowerCase())) results.push({areaId,h,i,areaName:areaObj(areaId).name});
    });
  });
  if(!results.length){box.innerHTML='<div class="result">검색 결과가 없습니다.</div>';return}
  box.innerHTML=results.map(r=>`<div class="result"><b>${r.areaName}</b><br>${r.h.no}. ${r.h.address}<br>${r.h.memo||''}<button class="small sub" onclick="openArea('${r.areaId}')">이 구역 열기</button></div>`).join('');
}

function addPerson(){
  const input=document.getElementById('personName');
  const name=input.value.trim();
  if(!name)return;
  let people=load('people',[]);
  if(!people.includes(name))people.push(name);
  save('people',people); input.value=''; renderAll();
}
function clearToday(){if(confirm('오늘 참여 명단을 초기화할까요?')){save('people',[]);save('pairs',[]);renderAll()}}
function renderPeople(){
  const people=load('people',[]);
  document.getElementById('peopleList').innerHTML=people.length?people.map((p,i)=>`${i+1}. ${p}`).join('<br>'):'아직 참여자가 없습니다.';
}
function pairedNames(){return load('pairs',[]).flatMap(p=>[p.a,p.b])}
function renderLeader(){
  const people=load('people',[]), used=pairedNames(), remain=people.filter(p=>!used.includes(p));
  ['p1','p2'].forEach(id=>{
    const s=document.getElementById(id);
    s.innerHTML='<option value="">선택</option>'+remain.map(p=>`<option>${p}</option>`).join('');
  });
  const pairs=load('pairs',[]);
  const all=calcArea('all');
  let areaLines=areas().filter(a=>a.id!=='all').map(a=>{
    const c=calcArea(a.id);
    return `■ ${a.name}: ${c.done}/${c.total} (${c.rate}%)`;
  }).join('<br>');
  document.getElementById('leaderDash').innerHTML=
    `오늘 참여: <b>${people.length}명</b><br>짝 편성: <b>${pairs.length}조</b><br>미편성: <b>${remain.length}명</b><br><br>${areaLines}<br><br>전체 진행률: <b>${all.rate}%</b>`;
  document.getElementById('pairList').innerHTML=pairs.length?pairs.map((p,i)=>`<div class="pair"><b>${i+1}조</b><br>${p.a} + ${p.b}<br>담당: ${p.area||'미지정'}</div>`).join(''):'아직 편성된 짝이 없습니다.';
  document.getElementById('remainList').innerHTML=remain.length?remain.join('<br>'):'남은 사람이 없습니다.';
}
function makePair(){
  const a=document.getElementById('p1').value,b=document.getElementById('p2').value,area=document.getElementById('pairArea').value;
  if(!a||!b||a===b){alert('서로 다른 두 사람을 선택하세요.');return}
  let pairs=load('pairs',[]); pairs.push({a,b,area}); save('pairs',pairs); renderAll();
}
function clearPairs(){if(confirm('짝 편성을 초기화할까요?')){save('pairs',[]);renderAll()}}

function standApply(){
  const name=prompt('전시대 신청자 이름');
  if(!name)return;
  let list=load('stand',[]); list.push({name,day:todayKey()}); save('stand',list);renderStand();
}
function clearStand(){if(confirm('전시대 기록을 초기화할까요?')){save('stand',[]);renderStand()}}
function renderStand(){
  const list=load('stand',[]);
  document.getElementById('standList').innerHTML=list.length?list.map((x,i)=>`${i+1}. ${x.day} - ${x.name}`).join('<br>'):'전시대 신청 기록이 없습니다.';
}

function exportBackup(){
  const obj={};
  for(let i=0;i<localStorage.length;i++){
    const key=localStorage.key(i);
    if(key && key.startsWith(K)) obj[key]=localStorage.getItem(key);
  }
  document.getElementById('backupBox').value=JSON.stringify(obj,null,2);
}
function importBackup(){
  const txt=document.getElementById('backupBox').value.trim();
  if(!txt){alert('복원할 백업 내용을 붙여넣으세요.');return}
  try{
    const obj=JSON.parse(txt);
    Object.keys(obj).forEach(k=>{if(k.startsWith(K))localStorage.setItem(k,obj[k])});
    alert('복원 완료'); renderAll();
  }catch(e){alert('백업 형식이 맞지 않습니다.')}
}
function resetVisitOnly(){
  if(!confirm('방문기록과 메모만 초기화할까요? 참여자와 짝 편성은 유지됩니다.'))return;
  Object.keys(localStorage).forEach(k=>{
    if(k.startsWith(K+'status_')||k.startsWith(K+'memo_')||k===K+'lastArea'||k===K+'lastHouseIndex') localStorage.removeItem(k);
  });
  renderAll();
}
function renderAll(){if(!DATA)return;renderBrief();renderPeople();renderLeader();renderStand();if(document.getElementById('area').classList.contains('active'))renderArea()}
init();
